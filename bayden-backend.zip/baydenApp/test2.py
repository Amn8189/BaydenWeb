from .tasks import sendmail

sendmail()