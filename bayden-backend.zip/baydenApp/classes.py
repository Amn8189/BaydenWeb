class Person:
    #constructor
    def __init__(self, firstname, secondname, car) :
        self.firstname= firstname
        self.scondname= secondname
        self.car= car